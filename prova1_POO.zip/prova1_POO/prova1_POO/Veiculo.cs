﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prova1_POO
{
    internal class Veiculo
    {
        // Atributos:
        string placa;
        int ano;
        public Veiculo() // Construtor default
        { 
        }

        public Veiculo(string placa, int ano) // Construturo de Aridade 2
        {
            this.placa = placa;
            this.ano = ano;
        }

        public string Placa { get => placa; set => placa = value; } // Getters e setters
        public int Ano { get => ano; set => ano = value; } // Getters e setters

        //Métodos

        public virtual double Alugar()
        {
            return 0.0;
        }


    }
}
