﻿namespace prova1_POO
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListViewGroup listViewGroup1 = new ListViewGroup("Placa", HorizontalAlignment.Left);
            ListViewGroup listViewGroup2 = new ListViewGroup("Ano", HorizontalAlignment.Left);
            ListViewGroup listViewGroup3 = new ListViewGroup("Assentos", HorizontalAlignment.Left);
            ListViewGroup listViewGroup4 = new ListViewGroup("Eixos", HorizontalAlignment.Left);
            ListViewGroup listViewGroup5 = new ListViewGroup("Diaria", HorizontalAlignment.Left);
            radioButtonCaminhao = new RadioButton();
            radioButtonOnibus = new RadioButton();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBoxAno = new TextBox();
            textBoxAssentos = new TextBox();
            pictureBox1 = new PictureBox();
            maskedTextBoxPlaca = new MaskedTextBox();
            buttonCadastrar = new Button();
            button2 = new Button();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // radioButtonCaminhao
            // 
            radioButtonCaminhao.AutoSize = true;
            radioButtonCaminhao.Location = new Point(125, 55);
            radioButtonCaminhao.Name = "radioButtonCaminhao";
            radioButtonCaminhao.Size = new Size(97, 24);
            radioButtonCaminhao.TabIndex = 0;
            radioButtonCaminhao.Text = "Caminhão";
            radioButtonCaminhao.UseVisualStyleBackColor = true;
            radioButtonCaminhao.CheckedChanged += radioButtonCaminhao_CheckedChanged;
            // 
            // radioButtonOnibus
            // 
            radioButtonOnibus.AutoSize = true;
            radioButtonOnibus.Checked = true;
            radioButtonOnibus.Location = new Point(287, 55);
            radioButtonOnibus.Name = "radioButtonOnibus";
            radioButtonOnibus.Size = new Size(76, 24);
            radioButtonOnibus.TabIndex = 1;
            radioButtonOnibus.TabStop = true;
            radioButtonOnibus.Text = "Ônibus";
            radioButtonOnibus.UseVisualStyleBackColor = true;
            radioButtonOnibus.CheckedChanged += radioButtonOnibus_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(157, 121);
            label1.Name = "label1";
            label1.Size = new Size(44, 20);
            label1.TabIndex = 2;
            label1.Text = "Placa";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(165, 156);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 3;
            label2.Text = "Ano";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(105, 192);
            label3.Name = "label3";
            label3.Size = new Size(96, 20);
            label3.TabIndex = 4;
            label3.Text = "Qtd Assentos";
            // 
            // textBoxAno
            // 
            textBoxAno.Location = new Point(219, 153);
            textBoxAno.Name = "textBoxAno";
            textBoxAno.Size = new Size(125, 27);
            textBoxAno.TabIndex = 5;
            // 
            // textBoxAssentos
            // 
            textBoxAssentos.Location = new Point(219, 189);
            textBoxAssentos.Name = "textBoxAssentos";
            textBoxAssentos.Size = new Size(125, 27);
            textBoxAssentos.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.onibusP1;
            pictureBox1.Location = new Point(480, 58);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(203, 154);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // maskedTextBoxPlaca
            // 
            maskedTextBoxPlaca.Location = new Point(219, 118);
            maskedTextBoxPlaca.Mask = "LLL-0000";
            maskedTextBoxPlaca.Name = "maskedTextBoxPlaca";
            maskedTextBoxPlaca.Size = new Size(125, 27);
            maskedTextBoxPlaca.TabIndex = 9;
            // 
            // buttonCadastrar
            // 
            buttonCadastrar.Location = new Point(178, 234);
            buttonCadastrar.Name = "buttonCadastrar";
            buttonCadastrar.Size = new Size(94, 29);
            buttonCadastrar.TabIndex = 11;
            buttonCadastrar.Text = "Cadastrar";
            buttonCadastrar.UseVisualStyleBackColor = true;
            buttonCadastrar.Click += buttonCadastrar_Click;
            // 
            // button2
            // 
            button2.Location = new Point(306, 234);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 12;
            button2.Text = "Limpar";
            button2.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5 });
            listViewGroup1.Header = "Placa";
            listViewGroup1.Name = "listViewGroupPlaca";
            listViewGroup2.Header = "Ano";
            listViewGroup2.Name = "listViewGroupAno";
            listViewGroup3.Header = "Assentos";
            listViewGroup3.Name = "listViewGroupAssetno";
            listViewGroup4.Header = "Eixos";
            listViewGroup4.Name = "listViewGroupEixo";
            listViewGroup5.Header = "Diaria";
            listViewGroup5.Name = "listViewGroupDiaria";
            listView1.Groups.AddRange(new ListViewGroup[] { listViewGroup1, listViewGroup2, listViewGroup3, listViewGroup4, listViewGroup5 });
            listView1.Location = new Point(79, 296);
            listView1.Name = "listView1";
            listView1.Size = new Size(308, 121);
            listView1.TabIndex = 13;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Placa";
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Ano";
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Assentos";
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Eixos";
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Diaria";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listView1);
            Controls.Add(button2);
            Controls.Add(buttonCadastrar);
            Controls.Add(maskedTextBoxPlaca);
            Controls.Add(pictureBox1);
            Controls.Add(textBoxAssentos);
            Controls.Add(textBoxAno);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(radioButtonOnibus);
            Controls.Add(radioButtonCaminhao);
            Name = "Form1";
            Text = "Cadastro de Veículos";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButtonCaminhao;
        private RadioButton radioButtonOnibus;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBoxAno;
        private TextBox textBoxAssentos;
        private PictureBox pictureBox1;
        private MaskedTextBox maskedTextBoxPlaca;
        private Button buttonCadastrar;
        private Button button2;
        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
    }
}