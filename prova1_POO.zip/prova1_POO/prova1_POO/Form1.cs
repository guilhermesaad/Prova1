using System.Windows.Forms;

namespace prova1_POO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void radioButtonOnibus_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.onibusP1;
            label3.Text = "Qtd Assentos";

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.caminh�o;
            label3.Text = "Qtd Eixos";

        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            listView1.Columns.Add()
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}