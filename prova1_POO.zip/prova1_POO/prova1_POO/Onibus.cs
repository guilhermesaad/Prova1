﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prova1_POO
{
    internal class Onibus:Veiculo
    {
        int assentos;

        public Onibus(): base()
        {

        }

        public Onibus(string placa, int ano, int assentos) : base(placa, ano) 
        { 
            this.assentos = assentos;
        }

        public int Assentos { get => assentos; set => assentos = value; }

        public override double Alugar()
        {
            double aluguel = (30 * Assentos) - (2023 - Ano) * 70;
            return aluguel;
        }
    }
}
